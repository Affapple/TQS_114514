package tqs.lab6_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab61Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab61Application.class, args);
	}

}
